README: Sleeping Teaching Assistant Project
Team Information
Team Members:
Name:Kenneth Ly
Section Number: 18007
Email: kennethly@csu.fullerton.edu
Name: Ethan Nguyen
Section Number: 18007
Email: ethantnguyen04@gmail.com
Name: Brian Muramatsu
Section Number: 18007
Email: briankota@csu.fullerton.edu
How to Run the Program
Platform
This program was developed and tested on a Linux environment with g++ compiler support for pthreads. Ensure that your system has the necessary dependencies installed. Program written in C++.
Compilation and Execution
cd to project:
Open the terminal and navigate to the project directory.
Compile using: 
sh r.sh
Run the program with the following command:
Run
./assignment2



Team Collaboration and Contribution
Our team collaborated on this project by dividing the responsibilities based on each member’s strengths and expertise. Each team member reviewed the code, provided feedback, and collaboratively debugged any issues encountered during testing. Regular meetings and code reviews ensured a synchronized and successful project development process.


Output Screenshot on bottom of Design Document